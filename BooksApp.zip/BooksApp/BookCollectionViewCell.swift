//
//  BookCollectionViewCell.swift
//  BooksApp
//
//  Created by 市村健太 on 2018/06/13.
//  Copyright © 2018年 GeekSalon. All rights reserved.
//

import UIKit

class BookCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var bookImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
